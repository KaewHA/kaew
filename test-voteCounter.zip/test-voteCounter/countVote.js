function countVote() {
  const votes = [];
  function addVote(numVote) {
    votes.push(numVote);
  }

  function getVoteDetail() {
    let objVote = {};

    votes.forEach((vote) => {
      if (objVote?.[vote] === undefined) {
        objVote[vote] = 1;
      } else {
        objVote[vote]++;
      }
    });
    return objVote;
  }
  return { addVote, getVoteDetail };
}

export { countVote };
