import { countVote } from "./countVote.js";
const { addVote, getVoteDetail } = countVote();

const initialPage = () => {
    const form = document.getElementById("vote")
    form.addEventListener("focus",voteInputFocus)
    form.addEventListener("blur",voteInputBlur)
    form.addEventListener("click",addVoteFromUser)

};

const voteInputFocus = (event) => {
    event.target.style.background = "#90EE90"
};
const voteInputBlur = (event) => {
    event.target.style.background = ""     
};

const addVoteFromUser = () => {
    const form = document.getElementById("vote")
    form.setAttribute("onclick","addVote()")
    addVote(document.getElementById("vote").value)
    const clear = document.getElementById("vote")
     clear.innerHTML = ''
    showVoteDetail();
};

const showVoteDetail = () => {
    const newCount = new countVote()
    // const newGet = new getVoteDetail() 
    const divid = document.getElementsByTagName("body").children
    divid[1].setAttribute("id","show")
    const cH1 = document.getElementById("show")
    cH1.createElement(H1)
    cH1.innerHTML = "Vote Counter:"
    const h1 = document.getElementById("show")
      for (const i = 0; i < newCount.length; i++) {
          const p = document.createElement("p")
          p.textContent = newCount[i].addVote+":"+newCount[i].getVoteDetail
          h1.appendChild(p)
        }

};

initialPage();
