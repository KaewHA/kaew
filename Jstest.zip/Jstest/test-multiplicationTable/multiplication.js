export class Multiplication {
  constructor(num) {
    this.num = num;
  }
  //Function นี้จะได้อาเรย์ออบเจ็คของสูตรคูณ ประกอบไปด้วย operand1 : ตัวถูกดำเนินการ1 ในข้อนี้คือ num ของแม่สูตรคูณที่รับเข้ามา
  //operand2 : ตัวถูกดำเนินการ2 คือลำดับ 1-12 operator : เครื่องหมายในกรณีของโจทย์คือ ตัวคูณ x และ result ผลลัพธ์การคูณ
  getArrayOfMutiplicationTable() {
    let arrayMultiplication = [];
    for (let i = 1; i <= 12; i++) {
      arrayMultiplication.push({
        operand1: this.num,
        operand2: i,
        operator: "x",
        result: this.num * i,
      });
    }
    return arrayMultiplication;
    
  }
  
}


