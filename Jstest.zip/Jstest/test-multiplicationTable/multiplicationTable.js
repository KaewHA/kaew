import { Multiplication } from "./multiplication.js";

const initialPage = () => {
   const genbtn = document.getElementById("generate")
   genbtn.style.backgroundcolor='#4CAF50'
   genbtn.addEventListener('click',showMutiplicationTable)

   const resetbtn = document.getElementById("reset")
   resetbtn.addEventListener('click', resetMutiplicationTable)
};

const showMutiplicationTable = () => {

    document.getElementById("showMultiplicationTable").innerHTML = ""
    
 

    // const num=document.getElementById("num").Value
    // Multiplication
    // const ul =document.getElementById("showMultiplicationTable")
    // for (let i=0; i<=12; i++){
    //     let li=i.array[i]
    //     li =document.createElement('li').document.createTextNode(arr[i].getArrayOfMutiplicationTable(num))
    //     ul.appendChild(li);
    // }
   
    document.getElementById("reset").style.backgroundColor = "red"
};

const resetMutiplicationTable = () => {
    document.getElementById("showMultiplicationTable").innerHTML = ""
    document.getElementById("num").innerHTML = ""
    document.getElementById("reset").style.backgroundColor = ""
};

initialPage();

return {
    initialPage,
    showMutiplicationTable,
    resetMutiplicationTable
}
