class product {
    constructor(name, description, price, quantity){
        this.stock = []
        this.name=name
        this.description=description
        this.price=price
        this.quantity=quantity
    }

    getTotalPrice(){
        let totalPrice = 0
        if(quantity === 0 || quantity < 0 ){return undefined}
           this.stock.forEach((name)=>{totalPrice+=name.quantity}) 
           //เรียกตัวสินค้าทุกตัว แล้วราคาสินค้ามาบวกกัน = totalPrice
           return totalPrice
    }

    findItemIndex(name){
        return this.stock.findIndex(prod=>prod.name == name)   
   //หาindexของสินค้าเพื่อจะเอาไปใช้ต่อ
    }

    sell(name,quantity){
        
        if(quantity === undefined || quantity === null || quantity === 0 || quantity < 0){return undefined}
          if(this.findItemIndex(name)>=0){
               let item =  this.stock[this.findItemIndex(name)].quantity 
               //ใช้indexที่ได้มาในการหาquantityและนำไปคำนวณต่อ
               if(item - quantity < 0){
                    this.stock[this.findItemIndex(name)].quantity = 0
                    return {name: name, quantity: quantity} 
                    
               }else{
                    this.stock[this.findItemIndex(name)].quantity -= quantity 
                    return {name: name, quantity: quantity} 
               }
          }
          
    }

}
