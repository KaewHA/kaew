class Bookrent {
    constructor(){
        this.books = []
    }

    addBook(book){
        for (let i = 0; i < this.books.leght; i++){
           if (this.books[i].id === book.id) {
            return null
            //loop หาว่าidเท่ากันหรือไม่ ถ้าเหมือนกัน return null
            }  
       }
       this.books.push(book) //add book ไปเก็บใน array books
        return book //แสดง book ที่ add ได้
        
    }

    rentBook(bookId){
        for (let i = 0; i < this.books.leght; i++) {
            if (this.books[i].id === bookId) {//เช็คจาก id ว่ามีเหมือนกันหรือไม่
              if (books.status) {//ถ้า status เป็น true
                this.books.status = false;//เปลี่ยนเป็น false
                return books;//แสดง books ที่ยืมได้
              } 
              return -1 //ถ้า status เป็น false return -1
            }
          }
        if (!this.books.id){//ถ้าไม่มี id
            return -1//return -1
        }
      
    }
}


const bookrent = new Bookrent(8)
console.log(bookrent.addBook({id: 1, title: "Javaa Programming", status: true}));
console.log(bookrent.addBook({id: 2, title: "Java Script Programming", status: true}));
console.log(bookrent.addBook({id: 4, title: "Its", status: true}));
console.log(bookrent.addBook({id: 4, title: "Its", status: true}));
console.log(bookrent.addBook({id: 8, title: "Happy Potter", status: true}));
console.log(bookrent.rentBook(1));
console.log(bookrent.rentBook(10));