import { countVote } from "./countVote.js";
const { addVote, getVoteDetail } = countVote();

const initialPage = () => {
    const form = document.getElementById("vote")
    form.addEventListener("focus",voteInputFocus)
    form.addEventListener("blur",voteInputBlur)
    form.addEventListener("click",addVoteFromUser)

};

const voteInputFocus = (event) => {
    event.target.style.background = "#90EE90"
};
const voteInputBlur = (event) => {
    event.target.style.background = ""     
};

const addVoteFromUser = () => {
    const form = document.getElementById("vote")
    form.setAttribute("onclick","addVote()")
    addVote(document.getElementById("vote").value)
    const clear = document.getElementById("vote")
     clear.innerHTML = ''
    showVoteDetail();
};

const showVoteDetail = () => {
    const newCount = new countVote()
    // const newGet = new getVoteDetail() 
    const divid = document.getElementsByTagName("body").children
    divid[1].setAttribute("id","show")
    const cH1 = document.getElementById("show")
    cH1.createElement(H1)
    cH1.innerHTML = "Vote Counter:"
    const h1 = document.getElementById("show")
      for (const i = 0; i < newCount.length; i++) {
          const p = document.createElement("p")
          p.textContent = newCount[i].addVote+":"+newCount[i].getVoteDetail
          h1.appendChild(p)
        }

};

// initialPage();


// function initialPage() {
//     // Add voteInputFocus function to the focus event of the input box
//     document.getElementById("vote").addEventListener("focus", voteInputFocus);
  
//     // Add voteInputBlur function to the blur event of the input box
//     document.getElementById("vote").addEventListener("blur", voteInputBlur);
  
//     // Add addVoteFromUser function to the click event of the button element
//     document.querySelector("button").addEventListener("click", addVoteFromUser);
//   }
  
//   function voteInputFocus(event) {
//     // Change the background color of the input box when it receives focus
//     event.target.style.backgroundColor = "#90EE90";
//   }
  
//   function voteInputBlur(event) {
//     // Change the background color of the input box back to its default color
//     event.target.style.backgroundColor = "";
//   }
  
//   function addVoteFromUser() {
//     // Retrieve data from the input box
//     var voteInput = document.getElementById("vote");
//     var voteValue = parseInt(voteInput.value);
  
//     // Add the vote value using the addVote function from countVote.js
//     addVote(voteValue);
  
//     // Clear the input box
//     voteInput.value = "";
  
//     // Call the showVoteDetail function
//     showVoteDetail();
//   }
  
//   function showVoteDetail() {
//     // Clear the content within the div tag
//     var voteDetailContainer = document.querySelector("div");
//     voteDetailContainer.innerHTML = "";
  
//     // Create an h1 tag with the text "Vote Counter:"
//     var heading = document.createElement("h1");
//     heading.textContent = "Vote Counter:";
//     voteDetailContainer.appendChild(heading);
  
//     // Retrieve the vote details in object format using the getVoteDetail function
//     var voteDetails = getVoteDetail();
  
//     // Generate p tags for each vote detail and append them under the h1 tag
//     for (var vote in voteDetails) {
//       var voteText = vote + ": " + voteDetails[vote];
//       var paragraph = document.createElement("p");
//       paragraph.textContent = voteText;
//       voteDetailContainer.appendChild(paragraph);
//     }
//   }
  
//   // Call the initialPage function to initialize the page
//   initialPage();