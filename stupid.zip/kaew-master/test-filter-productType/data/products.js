const products = [
{
id: 1,
name: "Laptop",
description: "A high-performance laptop with a large display and fast processor.",
type: "Electronics",
price: 899.99,
quantity: 10
},

{
id: 2,
name: "Smartphone",
description: "A sleek and powerful smartphone with advanced features.",
type: "Electronics",
price: 699.99,
quantity: 20
},

{
id: 3,
name: "Smartwatch",
description: "A stylish and functional smartwatch with health tracking features.",
type: "Electronics",
price: 199.99,
quantity: 5
},

{
id: 4,
name: "Camera",
description: "A high-quality camera with advanced features for professional photography.",
type: "Electronics",
price: 1299.99,
quantity: 2
},

{
id: 5,
name: "Headphones",
description: "A premium pair of noise-cancelling headphones for immersive audio experience.",
type: "Electronics",
price: 349.99,
quantity: 8
},

{
id: 6,
name: "Backpack",
description: "A durable and spacious backpack for carrying essentials during travel.",
type: "Fashion",
price: 99.99,
quantity: 15
},

{
id: 7,
name: "Sneakers",
description: "A trendy pair of sneakers with comfortable cushioning for daily wear.",
type: "Fashion",
price: 129.99,
quantity: 12
},

{
id: 8,
name: "Leather Jacket",
description: "A stylish and rugged leather jacket for colder weather.",
type: "Fashion",
price: 399.99,
quantity: 4
},

{
id: 9,
name: "Smart Thermostat",
description: "A wifi-enabled smart thermostat with automatic temperature adjustment.",
type: "Home",
price: 199.99,
quantity: 6
},

{
id: 10,
name: "Robot Vacuum",
description: "An intelligent robot vacuum cleaner for effortless cleaning.",
type: "Home",
price: 349.99,
quantity: 3
},

{
id: 11,
name: "Air Purifier",
description: "A high-quality air purifier with advanced filtration system for cleaner air.",
type: "Home",
price: 299.99,
quantity: 7
},

{
id: 12,
name: "Portable Speaker",
description: "A compact and wireless portable speaker for on-the-go music.",
type: "Electronics",
price: 99.99,
quantity: 18
},

{
id: 13,
name: "Bluetooth Earbuds",
description: "A pair of sleek and wireless earbuds with high-quality sound.",
type: "Electronics",
price: 149.99,
quantity: 10
},

{
id: 14,
name: "Fitness Tracker",
description: "A versatile fitness tracker with heart rate monitoring and GPS tracking.",
type: "Electronics",
price: 79.99,
quantity: 9
},
{
id: 15,
name: "Apple MacBook Pro",
description: "A powerful laptop with a Retina display and long battery life.",
type: "Computers",
price: 1499.99,
quantity: 25
},
{
id: 16,
name: "Microsoft Surface Pro 7",
description: "A versatile tablet with a detachable keyboard and touch screen.",
type: "Computers",
price: 899.99,
quantity: 30
},
{
id: 17,
name: "Canon EOS R5",
description: "A high-end mirrorless camera with 8K video recording and advanced autofocus.",
type: "Photography",
price: 3799.99,
quantity: 9
},
{
id: 18,
name: "DJI Mavic Air 2",
description: "A high-end drone with a 4K camera and long battery life.",
type: "Photography",
price: 799.99,
quantity: 10
},
{
id: 19,
name: "Fitbit Charge 5",
description: "A fitness tracker with GPS and heart rate monitoring.",
type: "Wearable technology",
price: 179.99,
quantity: 35
},
{
id: 20,
name: "Garmin Forerunner 945",
description: "A GPS running watch with advanced training features.",
type: "Wearable technology",
price: 599.99,
quantity: 15
}
]

export { products }
// module.exports = products;