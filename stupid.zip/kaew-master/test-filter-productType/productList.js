import { products } from "./data/products.js";
import { getArrayProductType } from "./productType.js";

function productList(productSource) {
  const products = productSource;
  const a = document.createElement("button")
    const x = document.getElementsById("productType")
  const initialPage = () => {
    
    //   for(i = 0; i = products.lenght; i++){  ลูปพยายามสร้างปุ่ม
    //   const x = document.getElementsById("productType") x getElementsById("productType")
    //   const btn = document.createElement("button") btn สร้างปุ่ม
    //   btn.setAttribute("id", products.type)set idให้เป็นตาม typeของproducts
    //   btn.textContent(products.type) set ข้อความเป็นชื่อปุ่มตามtype
    //   btn.style.marginRight="5px" set marginRight="5px"
    //   btn.addEventListener("click", showProductsByType) addevent และ functionshowProductsByType
    //   x.appendChild(btn) นำปุ่มที่สร้างมา ใส่ใน productType
    // }
    // 
  };

  const showProductsByType = (productType) => {
    const ul = document.getElementById('products')
    ul.textContent = ''
    getArrayProductType(productType).forEach(i => {
    const li = document.createElement('li')
    li.textContent = `id: ${i.id} ,name: ${i.name} ,type: ${i.type}`
    ul.appendChild(li)
  });
    // สร้างลูปสร้างliมีข้อความid: ${i.id} ,name: ${i.name} ,type: ${i.type} แล้วเพิ่มในul ul = document.getElementById('products')
  };



  return { initialPage, showProductsByType };
}

const { initialPage, showProductsByType } = productList(products);
initialPage();
