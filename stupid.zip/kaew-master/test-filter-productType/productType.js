export function getArrayProductType(products) {
  return Array.from(new Set(products.map((product) => product.type)));
}
