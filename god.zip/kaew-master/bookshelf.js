class Book {
  constructor(title, author, genre) {
    this.title = title;
    this.author = author;
    this.genre = genre;
  }
}

class Bookshelf {
  constructor(capacity) {
    this.capacity = capacity;
    this.books = [];
  }

  addBook(title, author, genre) {
    if (this.books.length >= this.capacity) {
      return null;
    }
    if (!title) {
      return undefined;
    }

    const book = new Book(title, author, genre);
    this.books.push(book);
    return book;
  }

  removeBook(title) {
    const removedBooks = [];
    for (let i = this.books.length - 1; i >= 0; i--) {
      if (this.books[i].title.toLowerCase() === title.toLowerCase()) {
        removedBooks.push(this.books.splice(i, 1)[0]);
      }
    }

    if (removedBooks.length > 0) {
      return removedBooks;
    } else {
      return -1;
    }
  }

  getBooksByGenre(genre) {
    const filteredBooks = this.books.filter(
      (book) => book.genre.toLowerCase() === genre.toLowerCase()
    );
    return filteredBooks;
  }
}

// ตัวอย่างการใช้งาน
const bookshelf = new Bookshelf(5);
console.log(bookshelf.addBook("Book 1", "Author 1", "Genre 1"));  // เพิ่มหนังสือลงในชั้นหนังสือ
console.log(bookshelf.addBook("Book 2", "Author 2", "Genre 1"));
console.log(bookshelf.addBook("Book 3", "Author 3", "Genre 2"));
console.log(bookshelf.addBook("Book 4", "Author 4", "Genre 2"));
console.log(bookshelf.addBook("", "Author 5", "Genre 3"));  // ไม่สามารถเพิ่มหนังสือได้
console.log(bookshelf.addBook("Book 5", "Author 5", "Genre 3"));
console.log(bookshelf.addBook("Book 6", "Author 6", "Genre 3"));  // เกินความจุของชั้นหนังสือ
console.log(bookshelf.removeBook("Book 2"));  // ลบหนังสือจากชั้นหนังสือ
console.log(bookshelf.removeBook("Book 10"));  // ไม่พบหนังสือที่ต้องการลบ
console.log(bookshelf.getBooksByGenre("Genre 1"));  // ดึงหนังสือตามหมวดหมู่
