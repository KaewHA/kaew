import { Multiplication } from "./multiplication.js";


function initialPage()  {
    
    document.getElementById("generate").style.backgroundColor = "#4CAF50"
    document.getElementById("generate").addEventListener("click", showMultiplicationTable)
    document.getElementById("reset").addEventListener("click", resetMutiplicationTable)
  };
  
 
  function showMultiplicationTable () {
     const clear = document.getElementById('showMultiplicationTable')
     clear.innerHTML = ''
    const inputNum = parseInt(document.getElementById('num').value)
    const newMultiplication = new Multiplication(inputNum) 
    const multiplicationTable = newMultiplication.getArrayOfMutiplicationTable()
    const ul = document.getElementById("showMultiplicationTable")
      for (var i = 0; i < multiplicationTable.length; i++) {
          var li = document.createElement("li")
          li.textContent = multiplicationTable[i].operand1 + " x " + multiplicationTable[i].operand2 + " = " +multiplicationTable[i].result
          ul.appendChild(li)
        }
        document.getElementById("reset").style.backgroundColor = "red"
  };
  

  function resetMutiplicationTable(){
    var ul = document.getElementById("showMultiplicationTable")
    ul.innerHTML = ""
    document.getElementById("num").value = ""
    document.getElementById("reset").style.backgroundColor = ""
  
  };

initialPage();


