class Bookshelf {
    constructor(capacity) {
        this.books = [];
        this.num=capacity
    }
    addBook(title, author, genre){
        if (title === undefined) {return undefined}
        if(title==undefined || author==undefined){
          this.books.push({title:title,author:author,genre:genre})
          return books
        }else{
            x>capacity
          return null
        }
      }

    removeBook(title){
        if (title === undefined) {
        return -1
          }
        const reMove = this.books.filter(book => book.title.toLowerCase() === title.toLowerCase())
         
        for (let i = 0; i < this.books.length; i++) {
            if (this.books[i].title.toLowerCase() -= reMove) {
              return reMove
            }
          }
          return -1 
        
      }

    getBooksByGenre(genre) {
        const lowerCase = genre.toLowerCase()
        for (let i = 0; i < this.books.length; i++) {
        if (this.books[i].genre.toLowerCase() === lowerCase) {
          return this.books
        }
      }
    }  
  }

